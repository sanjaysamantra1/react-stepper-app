import React from "react";

export default function Comp3() {
  return <div>Comp3 Loaded...</div>;
}
