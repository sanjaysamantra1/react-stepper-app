import React from "react";

export default function Comp2() {
  return <div>Comp2 Loaded....</div>;
}
