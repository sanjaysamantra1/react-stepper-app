import React from "react";

export default function Comp1() {
  return <div>Comp1 Loaded....</div>;
}
